<?php

use WeDevs\Dokan\Withdraw\Manager;

class Dokan_Withdraw extends Manager {}
