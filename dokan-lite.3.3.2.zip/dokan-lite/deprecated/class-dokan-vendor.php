<?php

use WeDevs\Dokan\Vendor\Vendor;

class Dokan_Vendor extends Vendor {}
